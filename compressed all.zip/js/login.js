/* ═══════════════════════════════════════════
   SCREEN SWITCHING
═══════════════════════════════════════════ */
function showScreen(id){
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

/* ── AUTH TAB SWITCHING ── */
function switchAuthTab(tab){
  ['signin','register'].forEach(t=>{
    document.getElementById('tab-'+t).className = 'sc-tab'+(t===tab?' active':'');
    document.getElementById('panel-'+t).style.display = t===tab?'':'none';
  });
}

function showGreeting(name){
  const greeting = getGreeting();

  // Topbar red pill
  const pill = document.getElementById('topbarUserName');
  if(pill){
    pill.textContent = `${greeting}, ${name}!`;
    pill.style.display = '';
  }

  // Setup screen greeting
  const setupGreeting = document.getElementById('setupGreeting');
  const setupGreetingText = document.getElementById('setupGreetingText');
  if(setupGreeting && setupGreetingText){
    setupGreetingText.textContent = `${greeting}, ${name}! Let's configure your dashboard.`;
    setupGreeting.style.display = '';
  }
}

document.addEventListener('DOMContentLoaded', ()=>{

  // Wire up tabs
  document.getElementById('tab-signin').addEventListener('click', ()=>switchAuthTab('signin'));
  document.getElementById('tab-register').addEventListener('click', ()=>switchAuthTab('register'));

  /* ── ADMIN BYPASS ── */
  const isAdmin = new URLSearchParams(window.location.search).get('admin') === 'true';
  if(isAdmin){
    // Admin is not a real account — sign out any lingering session so it
    // never inherits another user's saved history/data.
    auth.signOut().catch(()=>{});
    showScreen('screen-admin');
    // Hide sign out button for admin
    const logoutBtn = document.getElementById('btn-logout');
    if(logoutBtn) logoutBtn.style.display = 'none';
  }

  document.getElementById('btn-admin-enter').addEventListener('click', ()=>{
    showScreen('screen-setup');
    ['min','decent','max'].forEach(sc=>{ updateTotalCostFor(sc); });
  });

  /* ── SIGN IN ── */
  document.getElementById('btn-login').addEventListener('click', async ()=>{
    const email = document.getElementById('inp-email').value.trim();
    const pass = document.getElementById('inp-pass').value;
    const err = document.getElementById('login-error');
    err.textContent = '';
    try {
      const cred = await auth.signInWithEmailAndPassword(email, pass);
      const data = await loadUserData(cred.user.uid);
      if(data){
        userName = data.name || data.email || email;
        if(data.scenarios) scenarios = data.scenarios;
        if(data.globalEps) globalEps = data.globalEps;
      } else {
        userName = email;
      }
      showGreeting(userName);
      showScreen('screen-setup');
      ['min','decent','max'].forEach(sc=>{ updateTotalCostFor(sc); });
    } catch(e){
      console.warn('Login error code:', e.code, e.message);
      let msg;
      if(e.code === 'auth/user-not-found') msg = 'No account found with that email.';
      else if(e.code === 'auth/wrong-password') msg = 'Incorrect password. Please try again.';
      else if(e.code === 'auth/invalid-email') msg = 'That email address looks invalid.';
      else if(e.code === 'auth/too-many-requests') msg = 'Too many attempts. Please wait a moment and try again.';
      else if(e.code === 'auth/network-request-failed') msg = 'Network error. Check your connection and try again.';
      else if(e.code === 'auth/invalid-credential' || e.code === 'auth/invalid-login-credentials') msg = 'Incorrect email or password. Please try again.';
      else msg = `Sign-in succeeded but something else went wrong: ${e.message}`;
      err.textContent = msg;
      err.classList.add('show');
    }
  });

  /* ── FORGOT PASSWORD ── */
  document.getElementById('link-forgot-pass').addEventListener('click', async (e)=>{
    e.preventDefault();
    const email = document.getElementById('inp-email').value.trim();
    const msgEl = document.getElementById('forgot-pass-msg');
    const err = document.getElementById('login-error');
    err.textContent = ''; err.classList.remove('show');
    if(!email){
      err.textContent = 'Enter your email above first, then click "Forgot your password?".';
      err.classList.add('show');
      return;
    }
    try {
      await sendPasswordReset(email);
      msgEl.textContent = `Password reset link sent to ${email}. Check your inbox (and spam folder).`;
      msgEl.style.display = 'block';
    } catch(e){
      let msg = 'Could not send reset email. Please try again.';
      if(e.code === 'auth/user-not-found') msg = 'No account found with that email.';
      else if(e.code === 'auth/invalid-email') msg = 'That email address looks invalid.';
      err.textContent = msg;
      err.classList.add('show');
    }
  });

  /* ── REGISTER ── */
  document.getElementById('btn-register').addEventListener('click', async ()=>{
    const name = document.getElementById('inp-reg-name').value.trim();
    const email = document.getElementById('inp-reg-email').value.trim();
    const pass = document.getElementById('inp-reg-pass').value;
    const err = document.getElementById('register-error');
    err.textContent = '';
    if(!name){ err.textContent = 'Please enter your name.'; err.classList.add('show'); return; }
    try {
      const cred = await auth.createUserWithEmailAndPassword(email, pass);
      await saveUserData(cred.user.uid, { name, email });
      userName = name;
     showGreeting(userName);
      showScreen('screen-setup');
      ['min','decent','max'].forEach(sc=>{ updateTotalCostFor(sc); });
    } catch(e){
      err.textContent = e.message;  
      err.classList.add('show');
    }
  });

/* ── SIGN OUT ── */
  document.getElementById('btn-logout').addEventListener('click', async ()=>{
    if(isAdmin) return;
    await auth.signOut();
    userName = '';
    resetScenariosToDefault();
    globalEps = 4;
    const pill = document.getElementById('topbarUserName');
    if(pill){ pill.style.display = 'none'; }
    // Clear all fields and reset to sign in tab
    document.getElementById('inp-email').value = '';
    document.getElementById('inp-pass').value = '';
    document.getElementById('inp-reg-name').value = '';
    document.getElementById('inp-reg-email').value = '';
    document.getElementById('inp-reg-pass').value = '';
    document.getElementById('login-error').textContent = '';
    document.getElementById('login-error').classList.remove('show');
    document.getElementById('register-error').textContent = '';
    document.getElementById('register-error').classList.remove('show');
    switchAuthTab('signin');
    showScreen('screen-login');
  });

/* ── PROFILE MODAL ── */
  document.getElementById('btn-profile').addEventListener('click', ()=>{
    document.getElementById('inp-profile-name').value = userName || '';
    document.getElementById('inp-profile-email').value = auth.currentUser ? auth.currentUser.email : '';
    document.getElementById('inp-profile-currpass').value = '';
    document.getElementById('inp-profile-newpass').value = '';
    document.getElementById('inp-profile-currpass2').value = '';
    document.getElementById('profile-error').textContent = '';
    document.getElementById('profile-error').classList.remove('show');
    document.getElementById('profile-success').textContent = '';
    document.getElementById('profileModal').style.display = 'flex';
  });

  document.getElementById('btn-profile-save').addEventListener('click', async ()=>{
    const newName = document.getElementById('inp-profile-name').value.trim();
    const newEmail = document.getElementById('inp-profile-email').value.trim();
    const currPass = document.getElementById('inp-profile-currpass').value;
    const newPass = document.getElementById('inp-profile-newpass').value;
    const currPass2 = document.getElementById('inp-profile-currpass2').value;
    const errEl = document.getElementById('profile-error');
    const successEl = document.getElementById('profile-success');
    errEl.textContent = '';
    errEl.classList.remove('show');
    successEl.textContent = '';

    if(!newName){ errEl.textContent = 'Please enter a name.'; errEl.classList.add('show'); return; }

    const user = auth.currentUser;
    const emailChanged = newEmail && newEmail !== user.email;
    const passwordChanged = newPass && newPass.length > 0;
    let messages = [];

    try {
      // Update name
      await updateUserName(newName);
      userName = newName;
      showGreeting(userName);
      messages.push('Name updated');

      // Update email if changed
      if(emailChanged){
        if(!currPass){ errEl.textContent = 'Please enter your current password to change email.'; errEl.classList.add('show'); return; }
        try {
          await updateUserEmail(newEmail, currPass);
          messages.push('Email updated');
        } catch(e){
          let msg = 'Email update failed.';
          if(e.code === 'auth/wrong-password') msg = 'Incorrect current password for email change.';
          else if(e.code === 'auth/email-already-in-use') msg = 'This email is already in use.';
          else if(e.code === 'auth/requires-recent-login') msg = 'Please sign out and sign in again to change email.';
          errEl.textContent = msg;
          errEl.classList.add('show');
          return;
        }
      }

      // Update password if filled
      if(passwordChanged){
        if(newPass.length < 6){ errEl.textContent = 'New password must be at least 6 characters.'; errEl.classList.add('show'); return; }
        if(!currPass2){ errEl.textContent = 'Please enter your current password to change password.'; errEl.classList.add('show'); return; }
        try {
          await updateUserPassword(newPass, currPass2);
          messages.push('Password updated');
        } catch(e){
          let msg = 'Password update failed.';
          if(e.code === 'auth/wrong-password') msg = 'Incorrect current password for password change.';
          else if(e.code === 'auth/requires-recent-login') msg = 'Please sign out and sign in again to change password.';
          errEl.textContent = msg;
          errEl.classList.add('show');
          return;
        }
      }

      successEl.textContent = messages.join(' · ') + ' successfully!';

    } catch(e){
      errEl.textContent = 'Something went wrong. Please try again.';
      errEl.classList.add('show');
    }
  });

/* ── START OVER ── */
document.getElementById('btn-start-over').addEventListener('click',()=>{
    globalEps = 0;
    document.getElementById('global-eps').value = globalEps;
    resetScenariosToDefault();
    showScreen('screen-setup');
  });

/* ── AUTO SAVE when entering dashboard ── */
  document.getElementById('btn-enter-dash').addEventListener('click', async ()=>{
    cfg = { ...scenarios.decent };
    buildDashboard();
    showScreen('screen-dashboard');
    if(auth.currentUser){
      const netProfit = netProfitFor(scenarios.decent);
       await saveUserData(auth.currentUser.uid, {
        scenarios,
        globalEps,
      });
      await saveHistoryEntry(auth.currentUser.uid, {
        peakUsers: scenarios.decent.peakUsers,
        paidEps: globalEps,
        price: scenarios.decent.price,
        fixedCost: totalFixedFor(scenarios.decent),
        netProfit: netProfit,
        scenarios: scenarios,
      });
    }
  });

});

function closeProfileModal(){
  document.getElementById('profileModal').style.display = 'none';
}